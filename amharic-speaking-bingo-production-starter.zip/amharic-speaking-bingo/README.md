# Amharic Speaking Bingo

A production-oriented starter for an Ethiopian freemium language-learning product.

## Included
- Next.js App Router website configured for static export.
- Amharic Bingo prototype with random prompts, score and Bingo detection.
- Supabase email/password sign-up and sign-in.
- PostgreSQL migration with profiles, organizations, plans, subscriptions, questions, games and payment records.
- Row Level Security policies.
- Capacitor Android configuration.

## Important status
This is a starter project, not a launched production service. No Supabase project, domain, payment merchant account, hosting account, Android signing key or Play Store listing is included. Payment checkout is deliberately disabled until a trusted backend and merchant credentials are configured.

## Requirements
- Node.js 20.9+
- npm
- Supabase account/project
- Android Studio + Android SDK for Android packaging

## 1. Install
```bash
npm install
cp .env.example .env.local
```
On Windows PowerShell:
```powershell
Copy-Item .env.example .env.local
```

## 2. Create Supabase project
1. Create a project at https://supabase.com/dashboard.
2. Copy the Project URL and publishable/anon key from the project's API settings.
3. Put them in `.env.local`:
```env
NEXT_PUBLIC_SUPABASE_URL=https://YOUR_PROJECT_REF.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=YOUR_PUBLISHABLE_OR_ANON_KEY
```
The publishable/anon key is intended for client use when RLS is correctly configured. NEVER put a `service_role` or secret key in a `NEXT_PUBLIC_` variable or in the Android app.

## 3. Apply database migration
Option A: Supabase Dashboard -> SQL Editor -> paste and run:
`supabase/migrations/202611160001_initial_schema.sql`

Option B: Install Supabase CLI, link your project, then:
```bash
supabase login
supabase link --project-ref YOUR_PROJECT_REF
supabase db push
```
Review the migration and policies in a separate staging project before production. Run policy tests before inviting customers.

## 4. Configure Auth
In Supabase Dashboard -> Authentication -> URL Configuration:
- Site URL: your deployed website URL.
- Add local redirect URL for development if needed.
- Configure email confirmation and SMTP before public launch.
- Set password length and rate limits.
The included starter uses email/password auth. Phone OTP can be added after choosing an SMS provider and confirming local deliverability/cost.

## 5. Run locally
```bash
npm run dev
```
Open http://localhost:3000.

## 6. Build static website
```bash
npm run build
```
The static site is generated in `out/`. Deploy `out/` to a static host that supports HTTPS. Configure the Supabase Auth Site URL and allowed redirect URLs to match the final domain.

## 7. Android packaging
Install Android Studio and the Android SDK. Then:
```bash
npx cap add android
npm run build
npx cap sync android
npx cap open android
```
In Android Studio:
1. Wait for Gradle sync.
2. Set the app icon, splash screen and package identity.
3. Test on a physical Android device.
4. Generate a signed Android App Bundle (AAB) for Google Play.
5. Keep the signing key and passwords in secure backup; never commit them.

Capacitor 8 requires a compatible Android Studio/SDK setup. Check current Capacitor Android docs before upgrading dependencies.

## 8. Domain and deployment
Suggested first choice: `amharicbingo.com` (availability not checked).
Alternatives: `amharicspeakingbingo.com`, `amharicbingo.et`, `speakamharic.app`.
Check registration eligibility, price, renewal fees and ownership details before purchase. Register the domain in the founder's/business's own account, enable auto-renew and MFA, and use a business email.

For a static export, deploy the `out/` directory to a static host such as Vercel, Netlify or Cloudflare Pages. Add the custom domain in the host dashboard and follow its DNS instructions. Do not point DNS until the host verifies the domain.

## 9. Production gaps before taking money
- Add a server-side payment initiation endpoint (Supabase Edge Function or trusted backend).
- Store Chapa/Telebirr secret credentials only as server-side secrets.
- Verify provider webhook signature and independently verify transaction status, amount, currency and reference.
- Make webhook handling idempotent.
- Activate subscriptions only after verified successful payment.
- Add subscription expiry/renewal jobs and refunds/reconciliation.
- Add proper organization roles and school-level entitlements.
- Add anti-cheat validation: never trust client-submitted scores.
- Add rate limits, monitoring, backups, privacy policy, terms and support.
- Conduct RLS and penetration tests before public launch.

## 10. Current prototype limitations
- The Bingo board runs in the browser and is not yet saved to the database.
- Scores are local demonstration state, not trusted competition results.
- Premium plan buttons are informational only; no payment is taken.
- Admin dashboard and school management are not yet implemented.
- Voice recording and speech recognition are not included.
