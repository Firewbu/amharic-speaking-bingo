-- Amharic Speaking Bingo: initial production foundation
-- Apply with Supabase CLI: supabase db push
-- Review all policies in staging before production.

create extension if not exists pgcrypto;

create type public.app_role as enum ('student', 'teacher', 'admin');
create type public.organization_type as enum ('school', 'company', 'other');
create type public.subscription_status as enum ('pending', 'active', 'expired', 'cancelled');
create type public.payment_status as enum ('pending', 'paid', 'failed', 'refunded');
create type public.billing_period as enum ('free', 'monthly', 'yearly');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  role public.app_role not null default 'student',
  preferred_language text not null default 'am',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.organizations (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  organization_type public.organization_type not null default 'school',
  owner_id uuid not null references public.profiles(id),
  created_at timestamptz not null default now()
);

create table public.memberships (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  member_role text not null check (member_role in ('student','teacher','manager')),
  created_at timestamptz not null default now(),
  unique (organization_id, user_id)
);

create table public.plans (
  id uuid primary key default gen_random_uuid(),
  code text not null unique,
  name text not null,
  price_etb numeric(10,2) not null default 0 check (price_etb >= 0),
  billing_period public.billing_period not null,
  features jsonb not null default '{}'::jsonb,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table public.subscriptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete cascade,
  organization_id uuid references public.organizations(id) on delete cascade,
  plan_id uuid not null references public.plans(id),
  status public.subscription_status not null default 'pending',
  started_at timestamptz,
  expires_at timestamptz,
  created_at timestamptz not null default now(),
  check ((user_id is not null)::int + (organization_id is not null)::int = 1)
);

create table public.questions (
  id uuid primary key default gen_random_uuid(),
  question_text text not null,
  language_code text not null default 'am',
  category text not null default 'general',
  difficulty text not null default 'beginner'
    check (difficulty in ('beginner','intermediate','advanced')),
  is_premium boolean not null default false,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table public.games (
  id uuid primary key default gen_random_uuid(),
  created_by uuid not null references public.profiles(id),
  game_mode text not null default 'individual'
    check (game_mode in ('individual','group','classroom')),
  status text not null default 'waiting'
    check (status in ('waiting','active','completed','cancelled')),
  created_at timestamptz not null default now()
);

create table public.game_players (
  id uuid primary key default gen_random_uuid(),
  game_id uuid not null references public.games(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  score integer not null default 0 check (score >= 0),
  joined_at timestamptz not null default now(),
  unique (game_id, user_id)
);

create table public.game_answers (
  id uuid primary key default gen_random_uuid(),
  game_id uuid not null references public.games(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  question_id uuid not null references public.questions(id),
  score integer not null default 0 check (score >= 0),
  answer_note text,
  answered_at timestamptz not null default now()
);

create table public.payment_orders (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id),
  subscription_id uuid references public.subscriptions(id),
  provider text not null check (provider in ('chapa','telebirr','manual')),
  provider_reference text unique,
  amount_etb numeric(10,2) not null check (amount_etb > 0),
  currency text not null default 'ETB' check (currency = 'ETB'),
  status public.payment_status not null default 'pending',
  created_at timestamptz not null default now()
);

create table public.payment_events (
  id uuid primary key default gen_random_uuid(),
  payment_order_id uuid not null references public.payment_orders(id) on delete cascade,
  event_reference text not null unique,
  event_type text not null,
  verified boolean not null default false,
  received_at timestamptz not null default now()
);

create table public.audit_logs (
  id bigint generated always as identity primary key,
  actor_id uuid references public.profiles(id),
  action text not null,
  target_type text,
  target_id text,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create index memberships_user_idx on public.memberships(user_id);
create index memberships_org_idx on public.memberships(organization_id);
create index subscriptions_user_status_idx on public.subscriptions(user_id, status);
create index subscriptions_org_status_idx on public.subscriptions(organization_id, status);
create index questions_active_idx on public.questions(is_active, is_premium, category);
create index games_creator_idx on public.games(created_by, created_at desc);
create index game_players_user_idx on public.game_players(user_id);
create index payment_orders_user_idx on public.payment_orders(user_id, created_at desc);

-- Profile creation trigger. Role is always assigned server-side to student.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  insert into public.profiles (id, full_name)
  values (
    new.id,
    coalesce(new.raw_user_meta_data ->> 'full_name', '')
  );
  return new;
end;
$$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- Helper function prevents exposing other users' subscriptions.
create or replace function public.has_active_premium(check_user uuid)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1
    from public.subscriptions s
    join public.plans p on p.id = s.plan_id
    where s.user_id = check_user
      and s.status = 'active'
      and (s.expires_at is null or s.expires_at > now())
      and p.code in ('premium_monthly','premium_yearly')
  );
$$;

-- RLS on every exposed table.
alter table public.profiles enable row level security;
alter table public.organizations enable row level security;
alter table public.memberships enable row level security;
alter table public.plans enable row level security;
alter table public.subscriptions enable row level security;
alter table public.questions enable row level security;
alter table public.games enable row level security;
alter table public.game_players enable row level security;
alter table public.game_answers enable row level security;
alter table public.payment_orders enable row level security;
alter table public.payment_events enable row level security;
alter table public.audit_logs enable row level security;

-- Restrict privileges; service role remains backend-only.
revoke all on public.profiles, public.organizations, public.memberships,
 public.plans, public.subscriptions, public.questions, public.games,
 public.game_players, public.game_answers, public.payment_orders,
 public.payment_events, public.audit_logs from anon, authenticated;

grant select, update on public.profiles to authenticated;
grant select on public.organizations, public.memberships, public.subscriptions,
 public.payment_orders to authenticated;
grant select on public.plans, public.questions to anon, authenticated;
grant select, insert on public.games to authenticated;
grant select, insert on public.game_players to authenticated;
grant select, insert on public.game_answers to authenticated;

-- Profiles: users can see and update only themselves. Role cannot be changed by client:
-- For production, expose profile updates through a restricted RPC or column grants.
create policy "profile_read_own" on public.profiles
for select to authenticated using (id = (select auth.uid()));
create policy "profile_update_own" on public.profiles
for update to authenticated using (id = (select auth.uid()))
with check (id = (select auth.uid()) and role = 'student');

-- Organizations: owner can see and create their organization.
create policy "org_read_owner" on public.organizations
for select to authenticated using (owner_id = (select auth.uid()));
create policy "org_create_owner" on public.organizations
for insert to authenticated with check (owner_id = (select auth.uid()));

-- Membership: a user can see their own memberships; owners can see members in their org.
create policy "membership_read_self_or_owner" on public.memberships
for select to authenticated using (
  user_id = (select auth.uid()) or exists (
    select 1 from public.organizations o
    where o.id = organization_id and o.owner_id = (select auth.uid())
  )
);

-- Plans are public read-only.
create policy "plans_read_active" on public.plans
for select to anon, authenticated using (is_active = true);

-- Subscriptions are visible only to the subscribed user.
create policy "subscription_read_own" on public.subscriptions
for select to authenticated using (user_id = (select auth.uid()));

-- Questions: free questions are public; premium questions require active premium.
create policy "questions_read_free_or_premium" on public.questions
for select to anon, authenticated using (
  is_active = true and (
    is_premium = false or public.has_active_premium((select auth.uid()))
  )
);

-- Game creators can read their games; players can read games they joined.
create policy "games_read_creator_or_player" on public.games
for select to authenticated using (
  created_by = (select auth.uid()) or exists (
    select 1 from public.game_players gp
    where gp.game_id = id and gp.user_id = (select auth.uid())
  )
);
create policy "games_create_self" on public.games
for insert to authenticated with check (created_by = (select auth.uid()));

create policy "players_read_same_game" on public.game_players
for select to authenticated using (
  user_id = (select auth.uid()) or exists (
    select 1 from public.games g
    where g.id = game_id and g.created_by = (select auth.uid())
  )
);
create policy "players_join_self" on public.game_players
for insert to authenticated with check (user_id = (select auth.uid()));

-- Answers: user can see and insert only their own answers.
create policy "answers_read_own" on public.game_answers
for select to authenticated using (user_id = (select auth.uid()));
create policy "answers_insert_own" on public.game_answers
for insert to authenticated with check (
  user_id = (select auth.uid()) and score = 0
);

-- Payment orders are backend-created; users can only read their own.
create policy "payment_orders_read_own" on public.payment_orders
for select to authenticated using (user_id = (select auth.uid()));

-- No client policies for payment_events or audit_logs.
-- Inserts/updates to payment, subscription and audit tables must use trusted
-- Edge Functions or server-side service-role code only.

insert into public.plans (code, name, price_etb, billing_period, features)
values
 ('free','Free',0,'free','{"daily_questions":true,"basic_bingo":true}'::jsonb),
 ('premium_monthly','Premium Monthly',99,'monthly','{"advanced_questions":true,"progress_reports":true}'::jsonb),
 ('premium_yearly','Premium Yearly',999,'yearly','{"advanced_questions":true,"progress_reports":true}'::jsonb),
 ('school_monthly','School Monthly',1500,'monthly','{"teacher_dashboard":true,"classroom_games":true}'::jsonb)
on conflict (code) do nothing;
