# Secure payment architecture (implementation specification)

Do not implement payment initiation in the browser and do not expose provider secrets.

## Flow
1. Authenticated client calls an Edge Function `create-checkout`.
2. Function verifies the user's JWT and loads the requested active plan from `plans`.
3. Function creates a pending `payment_orders` row using the service role.
4. Function calls the payment provider using a server-side secret.
5. Function stores the provider reference and returns only the hosted checkout URL.
6. Provider sends a webhook to `payment-webhook`.
7. Function verifies the provider signature according to the provider's current documentation.
8. Function independently verifies the transaction with the provider API; compare merchant reference, amount and currency.
9. In one database transaction, record a unique payment event, mark the order paid, and activate/extend the subscription.
10. Repeated webhooks must be harmless (idempotent). Failed, reversed and refunded transactions must not grant access.

## Secrets
Store `CHAPA_SECRET_KEY` or Telebirr merchant credentials in Supabase Edge Function secrets. Never use `NEXT_PUBLIC_` for secrets. Never include a service-role key in the web bundle, mobile app, repository or issue tracker.

## Required controls
- Validate the requested plan and price on the server; never trust the client amount.
- Require authenticated user identity.
- Use random, unguessable transaction references.
- Verify webhook signatures and transaction status.
- Use unique constraints for provider references and webhook event IDs.
- Log provider responses without storing card or sensitive payment credentials.
- Reconcile pending payments periodically.
- Provide customer-visible receipts and support/refund process.

This project does not yet contain live payment functions. Implement and test them in a sandbox before production.
