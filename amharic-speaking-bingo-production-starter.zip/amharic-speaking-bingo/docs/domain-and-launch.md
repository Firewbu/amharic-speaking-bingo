# Domain and launch notes

Preferred candidate: amharicbingo.com.
Alternatives: amharicspeakingbingo.com, amharicbingo.et, speakamharic.app.

These are naming recommendations only; availability, trademark status, price and registration eligibility have not been checked. Search the chosen registrar and check business-name/trademark conflicts before purchase.

Register in the founder's own account, enable MFA and auto-renew, retain recovery codes, and use a business email. Configure HTTPS, DNS, Supabase Auth redirect URLs and privacy/contact pages before launch.
