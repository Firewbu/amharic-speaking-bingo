import type { Metadata, Viewport } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Amharic Speaking Bingo",
  description: "Learn, speak and play Amharic.",
  applicationName: "Amharic Speaking Bingo"
};

export const viewport: Viewport = {
  themeColor: "#174c3c",
  width: "device-width",
  initialScale: 1
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="am">
      <body>{children}</body>
    </html>
  );
}
