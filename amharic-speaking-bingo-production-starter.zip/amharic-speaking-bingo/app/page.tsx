"use client";

import { useEffect, useMemo, useState } from "react";
import type { User } from "@supabase/supabase-js";
import { getSupabase } from "@/lib/supabase";

const QUESTIONS = [
  "ራስህን አስተዋውቅ።","ስለ ቤተሰብህ ተናገር።","የምትወደውን ምግብ ግለጽ።","ስለ ትምህርት ቤትህ ንገረን።","የወደፊት ሕልምህ ምንድነው?",
  "ስለ ጓደኝነት ተናገር።","የምትወደውን ቦታ ግለጽ።","ስለ ኢትዮጵያ ባህል ተናገር።","አንድ ቀልድ ንገረን።","ስለ ስፖርት ተናገር።",
  "ስለ አካባቢ ጥበቃ ተናገር።","አንድ አስደሳች ትዝታ አጫውት።","ስለ ጤና ጥበቃ ተናገር።","ለጓደኛህ ምክር ስጥ።","የምትወደውን ወቅት ግለጽ።",
  "ስለ ገበያ ተናገር።","አንድ አዲስ ቃል አስተምረን።","ስለ ቴክኖሎጂ ጥቅም ተናገር።","በዝናብ ቀን ምን ታደርጋለህ?","የምትወደውን እንስሳ ግለጽ።",
  "ስለ አንድ ታዋቂ ሰው ተናገር።","የምትወደውን መጽሐፍ ግለጽ።","ስለ ዕለታዊ ተግባርህ ተናገር።","ስለ ትውልድ ቦታህ ተናገር።","ደስታን የሚያመጣልህን ነገር ግለጽ።",
  "ስለ ሙዚቃ ተናገር።","ስለ አየር ንብረት ተናገር።","ለአዲስ ተማሪ ምክር ስጥ።","ስለ ንግድ ሥራ ተናገር።","አንድ ታሪክ አጫውት።"
];

function shuffled<T,>(items: T[]) {
  const copy = [...items];
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
}

export default function Home() {
  const supabase = useMemo(() => getSupabase(), []);
  const [user, setUser] = useState<User | null>(null);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [authMode, setAuthMode] = useState<"signin" | "signup">("signup");
  const [authMessage, setAuthMessage] = useState("");
  const [question, setQuestion] = useState(QUESTIONS[0]);
  const [board, setBoard] = useState(() => shuffled(QUESTIONS).slice(0, 25));
  const [selected, setSelected] = useState<number[]>([12]);
  const [score, setScore] = useState(0);
  const [message, setMessage] = useState("ጥያቄውን በድምፅ መልስ፣ ከዚያ ተዛማጁን ሳጥን ምረጥ።");
  const [tab, setTab] = useState<"play" | "plans">("play");
  const [questionNumber, setQuestionNumber] = useState(0);

  useEffect(() => {
    if (!supabase) return;
    supabase.auth.getUser().then(({ data }) => setUser(data.user));
    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => setUser(session?.user ?? null));
    return () => listener.subscription.unsubscribe();
  }, [supabase]);

  const hasBingo = (marked: number[]) => {
    const set = new Set(marked);
    const lines: number[][] = [];
    for (let r = 0; r < 5; r++) lines.push(Array.from({ length: 5 }, (_, c) => r * 5 + c));
    for (let c = 0; c < 5; c++) lines.push(Array.from({ length: 5 }, (_, r) => r * 5 + c));
    lines.push([0, 6, 12, 18, 24], [4, 8, 12, 16, 20]);
    return lines.some(line => line.every(i => set.has(i)));
  };

  async function submitAuth(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!supabase) return setAuthMessage("እባክዎ .env.local ውስጥ Supabase URL እና key ያስገቡ።");
    setAuthMessage("በመላክ ላይ...");
    const result = authMode === "signup"
      ? await supabase.auth.signUp({ email, password, options: { data: { full_name: email.split("@")[0] } } })
      : await supabase.auth.signInWithPassword({ email, password });
    if (result.error) setAuthMessage(result.error.message);
    else if (authMode === "signup" && !result.data.session) setAuthMessage("የማረጋገጫ ኢሜይል ይመልከቱ።");
    else setAuthMessage("መለያዎ ተዘጋጅቷል።");
  }

  async function signOut() {
    if (supabase) await supabase.auth.signOut();
    setUser(null);
  }

  function newGame() {
    setBoard(shuffled(QUESTIONS).slice(0, 25));
    setSelected([12]);
    setScore(0);
    setMessage("አዲስ ጨዋታ ተጀምሯል። መልካም ዕድል!");
  }

  function markSquare(index: number) {
    if (index === 12 || selected.includes(index)) return;
    const next = [...selected, index];
    setSelected(next);
    setScore(s => s + 10);
    setMessage(hasBingo(next) ? "🎉 BINGO! እንኳን ደስ አለህ!" : "ጥሩ ነው! +10 ነጥብ። ቀጥል!");
  }

  function nextQuestion() {
    setQuestion(QUESTIONS[questionNumber % QUESTIONS.length]);
    setQuestionNumber(n => n + 1);
  }

  return (
    <main className="shell">
      <header className="topbar">
        <div className="brand"><div className="logo">🗣️</div><div>Amharic Speaking Bingo<div className="small muted">Learn • Speak • Play</div></div></div>
        {user ? <button className="btn secondary small" onClick={signOut}>ውጣ</button> : <span className="small muted">Free learning</span>}
      </header>

      <section className="hero">
        <div className="small">🇪🇹 የአማርኛ ቋንቋ ልምምድ</div>
        <h1>በመጫወት አማርኛ ተናገር!</h1>
        <p>ጥያቄዎችን መልስ፣ ንግግርህን አሻሽል፣ BINGO አሸንፍ።</p>
        <div className="row"><button className="btn" onClick={() => setTab("play")}>ጨዋታ ጀምር</button><button className="btn secondary" onClick={() => setTab("plans")}>Premium እቅዶች</button></div>
      </section>

      <section className="section card">
        <h2>👤 የተጠቃሚ መለያ</h2>
        {user ? <div className="notice">ጤና ይስጥልኝ! {user.email} — በመለያዎ ገብተዋል።</div> :
          <form onSubmit={submitAuth}>
            <p className="small muted">ውጤትህንና የPremium አባልነትህን ለማስቀመጥ መለያ ፍጠር።</p>
            <div className="row"><button type="button" className={`btn ${authMode === "signup" ? "" : "secondary"}`} onClick={() => setAuthMode("signup")}>መለያ ፍጠር</button><button type="button" className={`btn ${authMode === "signin" ? "" : "secondary"}`} onClick={() => setAuthMode("signin")}>ግባ</button></div>
            <label className="small">ኢሜይል</label><input className="input" type="email" required value={email} onChange={e => setEmail(e.target.value)} placeholder="you@example.com"/>
            <label className="small">የይለፍ ቃል (ቢያንስ 8 ቁምፊ)</label><input className="input" type="password" minLength={8} required value={password} onChange={e => setPassword(e.target.value)} placeholder="••••••••"/>
            <button className="btn" type="submit">{authMode === "signup" ? "መለያ ፍጠር" : "ግባ"}</button>
            {authMessage && <p className="notice">{authMessage}</p>}
            {!supabase && <p className="notice error">Supabase አልተዋቀረም። README ውስጥ ያለውን መመሪያ ይከተሉ።</p>}
          </form>}
      </section>

      <nav className="row section">
        <button className={`btn ${tab === "play" ? "" : "secondary"}`} onClick={() => setTab("play")}>🎮 ጨዋታ</button>
        <button className={`btn ${tab === "plans" ? "" : "secondary"}`} onClick={() => setTab("plans")}>💎 እቅዶች</button>
      </nav>

      {tab === "play" ? <section className="section card">
        <div className="row" style={{justifyContent:"space-between"}}><h2>🎯 የንግግር ጥያቄ</h2><strong>⭐ {score} ነጥብ</strong></div>
        <h2 style={{textAlign:"center",padding:"18px 4px"}}>{question}</h2>
        <div className="row"><button className="btn" onClick={nextQuestion}>🎲 ቀጣይ ጥያቄ</button><button className="btn secondary" onClick={newGame}>አዲስ ጨዋታ</button></div>
        <div className="section row" style={{justifyContent:"space-between"}}><strong>የቢንጎ ሰሌዳ</strong><span className="small muted">{selected.length - 1}/24 ተመርጠዋል</span></div>
        <div className="grid">{board.map((q,i)=><button key={`${q}-${i}`} className={`tile ${selected.includes(i) ? "selected" : ""}`} disabled={i===12 || selected.includes(i)} onClick={()=>markSquare(i)}>{i===12 ? "⭐ ነፃ" : q}</button>)}</div>
        <p className="notice section" aria-live="polite">{message}</p>
      </section> : <section className="section grid" style={{gridTemplateColumns:"repeat(auto-fit,minmax(220px,1fr))"}}>
        <div className="card"><h2>🆓 Free</h2><h1>0 ETB</h1><p className="small muted">Basic Bingo games and daily questions.</p><button className="btn secondary" onClick={()=>setTab("play")}>በነፃ ጀምር</button></div>
        <div className="card"><h2>💎 Premium</h2><h1>99 ETB</h1><p className="small muted">Proposed monthly price. Advanced questions and progress features.</p><button className="btn" onClick={()=>alert("የክፍያ ስርዓት ገና አልተገናኘም።")}>Premium ይምረጡ</button></div>
        <div className="card"><h2>🏫 School</h2><h1>1,500 ETB</h1><p className="small muted">Proposed monthly institutional package.</p><button className="btn secondary" onClick={()=>alert("እባክዎ የትምህርት ቤት ጥያቄዎን በኢሜይል ያቅርቡ።")}>ያግኙን</button></div>
      </section>}

      <footer className="footer">© {new Date().getFullYear()} Amharic Speaking Bingo. Learn • Speak • Play.<br/>Commercial starter project — payments are not yet enabled.</footer>
    </main>
  );
}
