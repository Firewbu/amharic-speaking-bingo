import type { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "et.amharicbingo.app",
  appName: "Amharic Speaking Bingo",
  webDir: "out",
  bundledWebRuntime: false
};

export default config;
